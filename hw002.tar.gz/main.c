#include <stdio.h>
#define MAX_LIM 10000
#define MIN_LIM -10000
#define outP printf("Vstup je mimo interval!\n"), ret = 1
#define r0 return 0

int checker(int a1, int b1){
    int ret = 0;
    a1 > MAX_LIM ? outP : a1 < MIN_LIM ? outP : b1 > MAX_LIM ? outP : b1 < MIN_LIM ? outP : 1;
    return ret;
}

int main(void){

    int a, b, check;
    scanf("%i %i", &a, &b);
    if (checker(a, b) == 1) { r0; }

    printf("Desitkova soustava: %i %i\n", a, b);
    printf("Sestnactkova soustava: %x %x\n", a, b);
    printf("Soucet : %i + %i = %i\n", a, b, a + b);
    printf("Rozdil : %i - %i = %i\n", a, b, a - b);
    printf("Soucin : %i * %i = %i\n", a, b, a * b);
    b != 0 ? printf("Podil : %i / %i = %i\n", a, b, a / b) : printf("Nedefinovany vysledek!\n");
    printf("Prumer : %3.1lf\n", (double)(a + b) / 2);

    r0;
}