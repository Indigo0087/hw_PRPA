#include <stdio.h>
#include <regex.h>
#include <sys/types.h>

#define errstr "Pocet vstupnich symbolu: %d\nPocet zakodovanych symbolu: %d\nKompresni pomer: %.2lf\n"
#define MAX_MATCHES 1

int pocetCisel(int n){ //rekursie pro pocet cifr "count"
    return n == 0 ? 0 : 1 + pocetCisel(n / 10);
}

int main(void){
    regex_t exp;
    char c, tmp;
    int count = 1, tot = 0, arch = 0, rexcom;
    scanf("%c", &c);
    tmp = c;    
    rexcom = regcomp(&exp, "[A-Z]", REG_EXTENDED); //compilace regexu s podminkou od A do Z
    if (rexcom != 0) printf("regcomp failed with %d\n", rexcom);
    
    while (scanf("%c", &c) != EOF)
    {   
        if (c == EOF) break;
        regmatch_t matches[MAX_MATCHES];//pole jen pro result
        if (regexec(&exp, &tmp, MAX_MATCHES, matches, 0) == 0) { //podminka ze mame ve vstupu 'A->Z' s pomoci regex
            if (c == tmp) count++;
            else {
                count > 256 ? fprintf(stdout, "%c255", tmp), count -= 255, arch += 4 : 0;
                if (count > 2) { fprintf(stdout, "%c%i", tmp, count); arch += pocetCisel(count) + 1; }
                else if (count == 2) { fprintf(stdout, "%c%c", tmp, tmp); arch += 2; }
                else { fprintf(stdout, "%c", tmp); arch++; }
                count = 1;   
            }

            tmp = c;
            tot++;

        } else 
        {
            regfree(&exp);
            fprintf(stderr, "%i\n", c);
            fprintf(stderr, "Error: Neplatny symbol!\n");
        
            return 100;
        }
    }

    regfree(&exp);
    fprintf(stdout, "\n");
    fprintf(stderr, errstr, tot, arch, (double) arch / tot);

    return 0;
}
