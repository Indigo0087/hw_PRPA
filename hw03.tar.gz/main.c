#include <stdio.h>
#include <math.h>
#define MAX_LIM 10000
#define MIN_LIM -10000
#define outP printf("\nError: Vstup je mimo interval!\n");

int main(void){

    int a = 0, i = 0, sude = 0, liche = 0, kladne = 0, zaporne = 0, sum = 0, max = MIN_LIM, min = MAX_LIM;

    while (1) {
            
        if (a > MAX_LIM || a < MIN_LIM)
            { outP return 100; }
        i++ == 0 ? scanf("%d", &a) : printf(", ");
        printf("%d", a);
        a > 0 ? kladne++ : a != 0 ? zaporne++ : 0;
        a % 2 == 0 ? sude++ : liche++;
        sum += a;
        a > max ? max = a : 0;
        a < min ? min = a : 0;
        if (scanf("%d", &a) == EOF) break;
    }

    printf("\n");
    printf("Pocet cisel: %d\n", i);
    printf("Pocet kladnych: %d\n", kladne);
    printf("Pocet zapornych: %d\n", zaporne);
    printf("Procento kladnych: %.2lf\n", (double) 100 * kladne / i);
    printf("Procento zapornych: %.2lf\n", (double) 100 * zaporne / i);
    printf("Pocet sudych: %d\n", sude);
    printf("Pocet lichych: %d\n", liche);
    printf("Procento sudych: %.2lf\n", (double) 100 * sude / i);
    printf("Procento lichych: %.2lf\n", (double) 100 * liche / i);
    printf("Prumer: %.2lf\n", (double) sum / i);
    printf("Maximum: %d\n", max);
    printf("Minimum: %d\n", min);

    return 0;
}
