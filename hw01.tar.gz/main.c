#include <stdio.h>

int main(void){
    printf("Hello PRPA!\n");
    return 0;
}
