#include <stdio.h>

#define errstr "Pocet vstupnich symbolu: %d\nPocet zakodovanych symbolu: %d\nKompresni pomer: %.2lf\n"
#define MAX_MATCHES 1

int pocetCisel(int n){ //rekursie pro pocet cifr "count"
    return n == 0 ? 0 : 1 + pocetCisel(n / 10);
}

int main(void){
    char c, tmp;
    int count = 1, tot = 0, arch = 0;
    scanf("%c", &c);
    tmp = c;    
    
    while (scanf("%c", &c) != EOF)
    {   
        if (tmp >= 65 && tmp <= 90) { //podminka ze mame ve vstupu 'A->Z' s pomoci regex
            if (c == tmp) count++;
            else {
                count > 256 ? fprintf(stdout, "%c255", tmp), count -= 255, arch += 4 : 0;
                if (count > 2) { fprintf(stdout, "%c%i", tmp, count); arch += pocetCisel(count) + 1; }
                else if (count == 2) { fprintf(stdout, "%c%c", tmp, tmp); arch += 2; }
                else { fprintf(stdout, "%c", tmp); arch++; }
                count = 1;   
            }

            tmp = c;
            tot++;

        } else 
        {
            fprintf(stderr, "Error: Neplatny symbol!\n");
        
            return 100;
        }
    }

    fprintf(stdout, "\n");
    fprintf(stderr, errstr, tot, arch, (double) arch / tot);

    return 0;
}
